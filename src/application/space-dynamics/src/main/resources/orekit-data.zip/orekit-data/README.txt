This zip file contains some data files useful for
use with the orekit library (http://www.orekit.org/).

In order to use this file, simply put it anywhere you
want and add its absolute path to the orekit.data.path
java property. There is no need to unzip the file, Orekit
will read directly into the zip.

This zip file contains JPL DE 406 ephemerides from 1962
to 2029, IERS Earth orientation parameters from 1973
to end 2012 with predicted date to mid-2013 (both IAU-1980
and IAU-2000), UTC-TAI history from 1972 to end of 2012,
Marshall Solar Activity Futur Estimation from 1999 to 2012
and the Eigen 06S gravity field.
